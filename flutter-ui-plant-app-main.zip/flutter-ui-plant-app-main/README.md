# Flutter UI - Plants App

An onboarding screen ui for a Plant App coded in Flutter and Dart
![plant-app](https://user-images.githubusercontent.com/102694446/173368186-5ac0d80f-d6f6-4594-98b3-838d95b0b8f8.png)

View Tutorial on YouTube
[https://youtu.be/YI64uyPSduE](https://www.youtube.com/watch?v=NWAJDtaovOU)
