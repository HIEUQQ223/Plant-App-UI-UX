package com.example.flutter_onboarding

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
